celsius = float(input())
fahren = celsius*9/5+32
print(fahren)